/*
 * SDCardTest.h
 *
 *  Created on: 17 jul. 2014
 *      Author: pbot
 */

#ifndef SDCARDTEST_H_
#define SDCARDTEST_H_

#include <hal/boolean.h>

#include <stdint.h>

Boolean SDCardTest( void );

#endif /* SDCARDTEST_H_ */
