/*
 * PWMtest.h
 *
 *  Created on: 27-Feb-2013
 *      Author: Akhil Piplani
 */

#ifndef PWMTEST_H_
#define PWMTEST_H_

#include <hal/boolean.h>

Boolean PWMtest();

#endif /* PWMTEST_H_ */
