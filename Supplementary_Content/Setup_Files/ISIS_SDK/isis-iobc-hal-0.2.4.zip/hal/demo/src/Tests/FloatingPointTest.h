/*
 * FloatingPointTest.h
 *
 *  Created on: 20-Feb-2013
 *      Author: Akhil Piplani
 */

#ifndef FLOATINGPOINTTEST_H_
#define FLOATINGPOINTTEST_H_

#include <hal/boolean.h>

Boolean floatingPointTest();

#endif /* FLOATINGPOINTTEST_H_ */
