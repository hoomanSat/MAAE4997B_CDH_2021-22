/*
 * SupervisorTest.h
 *
 *  Created on: Jun 21, 2013
 *      Author: ffat
 */

#ifndef SUPERVISORTEST_H_
#define SUPERVISORTEST_H_

#include "hal/boolean.h"

Boolean SupervisorTest(Boolean use_i2c);

#endif /* SUPERVISORTEST_H_ */
