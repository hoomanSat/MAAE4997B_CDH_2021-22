/*
 * ThermalTest.h
 *
 *  Created on: 11-Sep-2013
 *      Author: Akhil Piplani
 */

#ifndef THERMALTEST_H_
#define THERMALTEST_H_

Boolean thermalTest();

#endif /* THERMALTEST_H_ */
