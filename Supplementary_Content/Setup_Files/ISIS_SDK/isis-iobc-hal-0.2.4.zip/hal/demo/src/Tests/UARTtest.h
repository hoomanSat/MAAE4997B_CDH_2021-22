/*
 * UARTtest.h
 *
 *  Created on: 20-Feb-2013
 *      Author: Akhil Piplani
 */

#ifndef UARTTEST_H_
#define UARTTEST_H_

Boolean UARTtest();

#endif /* UARTTEST_H_ */
