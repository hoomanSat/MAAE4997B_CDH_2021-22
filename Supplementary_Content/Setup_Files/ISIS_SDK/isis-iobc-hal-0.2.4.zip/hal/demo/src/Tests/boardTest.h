/*
 * boardTest.h
 *
 *  Created on: 05-Mar-2014
 *      Author: apip
 */

#ifndef BOARDTEST_H_
#define BOARDTEST_H_

Boolean boardTest();

#endif /* BOARDTEST_H_ */
