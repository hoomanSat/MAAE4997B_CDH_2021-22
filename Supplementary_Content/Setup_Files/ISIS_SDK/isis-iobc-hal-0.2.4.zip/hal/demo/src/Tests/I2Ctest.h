/*
 * I2Ctest.h
 *
 *  Created on: 23-Jan-2013
 *      Author: Akhil Piplani
 */

#ifndef I2CTEST_H_
#define I2CTEST_H_

#include <hal/boolean.h>

Boolean I2Ctest();

#endif /* I2CTEST_H_ */
