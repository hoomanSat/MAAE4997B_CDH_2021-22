/*
 * I2CslaveTest.h
 *
 *  Created on: 11-Mar-2014
 *      Author: apip
 */

#ifndef I2CSLAVETEST_H_
#define I2CSLAVETEST_H_

Boolean I2CslaveTest();

#endif /* I2CSLAVETEST_H_ */
