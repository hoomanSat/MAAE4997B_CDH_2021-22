/*
 * version.h
 *
 *  Created on: 1-Sep-2014
 *      Author: jwar
 */

#ifndef HAL_VERSION_H_
#define HAL_VERSION_H_

extern const char HalCompileDate[];
extern const char HalCompileTime[];
extern const char HalVersionMajor[];
extern const char HalVersionMinor[];
extern const char HalVersionRevision[];

#endif /* HAL_VERSION_H_ */
